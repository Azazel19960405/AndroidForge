# Project Elysia — Aeon Viewer (Android)

This is an Android Studio project wrapping the browser-based Aeon Viewer in a native WebView shell.

## Build an APK

1. Install Android Studio (current stable) on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components (compile SDK 35).
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, usually:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer that APK to your Android device and install it. You may need to allow installs from that file manager.

## Notes

- The app loads the included `app/src/main/assets/index.html` viewer.
- The viewer compiles TSX in the WebView and imports React, Three.js, React Three Fiber, and esbuild-wasm from esm.sh, so an internet connection is required.
- The Android document picker is used for selecting TSX files.
- Only load TSX files you trust: they are executable JavaScript/TypeScript code.
- This source project is not itself an APK. It must be built and signed using Android Studio/Android SDK.
